<?php 
include_once "./layout/header.php";
?>

<h1>Work</h1>

<?php 
include_once "./layout/footer.php";
?>