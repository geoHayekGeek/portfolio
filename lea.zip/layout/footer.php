<div class="container-fluid" id="footer">
    <span class="h4 copyright">
        Copyright © 2024 <a target="_blank" href="https://wa.me/96176884670" class="link">Lea Najem</a>. All rights
        reserved.
    </span>
</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
    crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.9.1/gsap.min.js"></script>
<script src="assets/js/navbar.js"></script>
<script src="assets/js/socials.js"></script>
</body>

</html>